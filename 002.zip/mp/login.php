<?php
return <<<DF
a:2:{s:4:"user";s:5:"admin";s:4:"pass";s:6:"qweqwe";}
DF;
