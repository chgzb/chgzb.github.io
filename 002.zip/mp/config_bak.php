<?php
/*
* 账  号: admin
* 密  码: 123456
* 作者QQ: 3379530015
*/
return <<<DF
a:34:{s:4:"rise";i:1;s:4:"site";s:24:"鼎丰裂变引流程序";s:4:"path";s:1:"0";s:4:"user";s:5:"admin";s:4:"pass";s:6:"123456";s:3:"pre";s:2:"15";s:4:"m3u8";s:1:"0";s:4:"img1";s:18:"./images/topad.jpg";s:4:"img4";s:16:"./images/bot.gif";s:7:"timeTip";s:74:"更多精彩视频尽在<span style="color:red">精选/精品</span>平台";s:7:"timeOut";s:2:"50";s:7:"timeSrc";s:21:"http://www.baidu.com/";s:6:"census";s:1:"1";s:4:"deny";s:1:"0";s:4:"vdef";s:1:"5";s:4:"vadd";s:1:"5";s:5:"cache";s:5:"86400";s:5:"adth1";s:166:"分享好友后获得+5次的刷新机会<br><br>提示朋友打开才管用呦！<br><img src="images/here.png" style="width:90%;margin-top:13px;border-radius:5px;">";s:5:"adthe";s:82:"分享好友后获得+5次的刷新机会<br><br>提示朋友打开才管用呦！";s:5:"title";s:8:"QQ资源";s:5:"topad";s:21:"http://www.baidu.com/";s:5:"sInfo";s:144:"没有观看次数了！
①请复制转发到Q群 增加观看次数
②每有一人打开你就增加5次
③没有人打开不增加次数";s:5:"sText";s:66:"各种网红大瓜？等你来开？弟兄们速度上车！！###";s:4:"sEnd";s:44:"复制成功,返回QQ,粘贴发送到Q群吧";s:3:"shu";s:0:"";s:6:"tongji";s:0:"";s:5:"ready";s:65:"http://qm.qq.com/cgi-bin/qm/qr?k=eQkTaSZmzQq4TxNzqRN633RWLcBTee1Y";s:4:"btn2";s:28:"最新色播APP-点这下载";s:4:"url2";s:21:"http://www.baidu.com/";s:4:"btn3";s:39:"VIP线路高清原创速度快秒打开";s:4:"url3";s:21:"http://www.baidu.com/";s:4:"btn4";s:34:"点 这 里 进 QQ 群 无 限 看";s:4:"url4";s:21:"http://www.baidu.com/";s:6:"videos";s:301:"http://cyberplayer.bcelive.com/videoworks/mda-kbuhu4wqdi08dwix/cyberplayer/mp4/cyberplayer-demo.mp4
http://cyberplayer.bcelive.com/videoworks/mda-kbuhu4wqdi08dwix/cyberplayer/mp4/cyberplayer-demo.mp4
http://cyberplayer.bcelive.com/videoworks/mda-kbuhu4wqdi08dwix/cyberplayer/mp4/cyberplayer-demo.mp4";}
DF;
