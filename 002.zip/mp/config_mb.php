<?php
return <<<DF
{replace}
DF;
