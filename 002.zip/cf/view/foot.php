<footer><p><span>原作者的版本后台什么的都在他服务器上，他服务器卡了，后台就废了。破解版把后台移植到了本地，彻底摆脱原作者掌控</span></p>
    <p>本程序无代理，原作者：3379530015，破解者：小明</p></footer>
<script type="text/javascript">var $user = {
        "version": "V180195",
        "admin": "http:\/\/server.ll03.cn\/Acc\/?v=vAdm2",
        "name": "\u98de\u5f97\u66f4\u9ad8",
        "info": "qq.6.5.copy.h",
        "date": 1690180208,
        "token": "fcb62ca1",
        "path": "D:\/xm\/002\/cf.php",
        "host": "http:\/\/127.0.0.2\/cf.php?df",
        "addr": "127.0.0.1",
        "rise": 14,
        "cess": 4,
        "get": {"df": ""},
        "href": "\/\/server.ll03.cn\/Acc\/vAdm2",
        "save": 0,
        "debug": 0,
        "type": "setting"
    };</script>
<script type="text/javascript" src="/style/js/layer.js"></script>
<script type="text/javascript" src="/style/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/style/js/copyright.js?11"></script>
<script type="text/javascript" src="/style/js/admin.js?11"></script>
<script type="text/javascript">
    $(function(){
        if(!/7953/.test($('footer').html())){
            location.href='http://www.baidu.com/';
        }
    })
</script>
</body>
</html>