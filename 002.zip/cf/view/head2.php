<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport"
          content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="Cache-Control" content="public">
    <title>参数设置</title>
    <link rel="stylesheet" href="/style/css/bootstrap.min.css">
    <link rel="shortcut icon" type="image/x-icon" href="//server.ll03.cn/Acc/static/favicon.ico">
    <link rel="stylesheet" type="text/css" href="/style/css/layer.css">
    <link rel="stylesheet" type="text/css" href="/style/css/admin.css">
    <script type="text/javascript" src="/style/js/jquery.min.js"></script>
</head>
<body>
<nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
        <div class="navbar-header"><a class="navbar-brand" href="?">
                鼎丰裂变引流程序 </a>
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                    aria-expanded="false" aria-controls="navbar"><span class="sr-only">导航按钮</span><span
                    class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
        </div>
    </div>
</nav>