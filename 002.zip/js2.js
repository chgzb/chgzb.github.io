(function anonymous() {
        document.write("\n\n\n\n<script>\nvar host = '.';\nvar h\t= '';\nh\t+= '<link href=\"'+host+'\/images\/layer.css\" rel=\"stylesheet\" type=\"text\/css\">';\nh\t+= '<script src=\"'+host+'\/images\/jquery.min.js\"><\\\/script>';\nh\t+= '<script src=\"'+host+'\/images\/DPlayer\/hls.min.js\"><\\\/script>';\nh\t+= '<script src=\"'+host+'\/images\/DPlayer\/DPlayer.min.js\"><\\\/script>';\nh\t+= '<script src=\"'+host+'\/images\/layer.js\"><\\\/script>';\nh\t+= '<script src=\"'+host+'\/mp\/config.js?'+Math.random()+'\"><\\\/script>';\nh\t+= '<script src=\"'+host+'\/images\/index.js?'+Math.random()+'\"><\\\/script>';\ndocument.write( h );\n<\/script>\n\n\n\n");
    }
)("sojson.df")
